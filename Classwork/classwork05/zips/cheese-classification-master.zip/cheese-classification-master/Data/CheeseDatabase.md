| Milk Source | Country        | Cheese              | Type      | Texture      | Colour      | Flavour | Aroma    | Common Usage  |
|-------------|----------------|---------------------|-----------|--------------|-------------|---------|----------|---------------|
| cow         | netherlands    | Gouda               | semi-hard | firm         | yellow      | rich    | pungent  | table-cheese  |
| cow         | england        | Cheddar             | hard      | firm         | yellow      | strong  | none     | melting       |
| cow         | france         | Brie                | soft      | smooth       | white       | creamy  | none     | bread         |
| cow         | italy          | Parmesan            | hard      | crumbly      | white       | strong  | strong   | pasta         |
| cow         | italy          | Mozzarella          | semi-soft | springy      | white       | creamy  | none     | pizza         |
| goat        | greece         | Feta                | soft      | crumbly      | white       | rich    | strong   | salad         |
| cow         | italy          | Asiago              | hard      | crumbly      | yellow      | mild    | pungent  | salad         |
| cow         | italy          | Mascarpone          | soft      | smooth       | white       | mild    | none     | salad         |
| cow         | united states  | Muenster            | soft      | smooth       | pale-yellow | mild    | pungent  | melting       |
| cow         | united states  | Montery Jack        | semi-hard | creamy       | pale-yellow | mild    | pleasant | table-cheese  |
| cow         | italy          | Ricotta             | soft      | creamy       | white       | sweet   | none     | cooking       |
| cow         | united kingdom | Cottage Cheese      | soft      | creamy       | white       | sweet   | none     | dip           |
| Cow         | italy          | Gorgonzola          | blue      | firm         | yellow      | mild    | none     | pizza         |
| cow         | united states  | Cream Cheese        | soft      | creamy       | white       | creamy  | pleasant | cheesecake    |
| cow         | denmark        | Danish Blue         | blue      | creamy       | white       | strong  | none     | dressing      |
| cow         | Norway         | Jarlsberg           | semi-soft | smooth       | pale-yellow | mild    | none     | melting       |
| cow         | italy          | Provolone           | semi-hard | firm         | pale-yellow | strong  | pleasant | melting       |
| cow         | france         | Cantal              | semi-hard | crumbly      | pale-yellow | sweet   | strong   | salad         |
| sheep       | france         | Roquefort           | blue      | creamy       | pale-yellow | strong  | none     | cooking       |
| cow         | france         | Fromage Blanc       | soft      | smooth       | white       | mild    | mild     | table-cheese  |
| cow         | england        | Stilton             | semi-soft | smooth       | yellow      | strong  | none     | table-cheese  |
| Cow         | france         | Explorateur         | soft      | smooth       | white       | mild    | none     | salad         |
| Cow         | france         | Reblochon           | semi-soft | firm, smooth | white       | mild    | mild     | table-cheese  |
| cow         | spain          | Castigliano         | hard      | firm         | yellow      | spicy   | pleasant | table-cheese  |
| sheep       | italy          | Caciotta al Tartufo | semi-soft | firm         | white       | mild    | pungent  | salad         |
| goat        | united kingdom | Innes Button        | soft      | smooth       | white       | rich    | none     | bread         |
| cow         | germany        | Brunost             | semi-soft | firm         | yellow      | sweet   | none     | dip           |
| Cow         | Switzerland    | Sapsago             | hard      | firm         | green       | rich    | pleasant | bread         |
| sheep       | italy          | Calcagno            | hard      | smooth       | pale-yellow | rich    | pleasant | salad         |
| sheep       | spain          | Manchego            | semi-soft | smooth       | pale-yellow | sweet   | none     | table-cheese  |
