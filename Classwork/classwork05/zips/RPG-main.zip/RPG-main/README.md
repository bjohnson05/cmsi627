# RPG
CLIPS Programs implementing some tasks in Role-Playing Games.
